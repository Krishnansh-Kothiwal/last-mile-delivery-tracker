---
name: Logistics & Operational Intelligence
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  success: '#16a34a'
  pending: '#d97706'
  critical: '#dc2626'
  slate-900: '#0f172a'
  slate-200: '#e2e8f0'
typography:
  display-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  mono-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin: 24px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for high-stakes operational environments where speed of comprehension and data accuracy are paramount. The personality is **authoritative, precise, and utilitarian**, catering to logistics coordinators and dispatchers who manage high volumes of real-time data.

The aesthetic follows a **Modern Corporate** approach with a focus on functional density. It prioritizes a "Data-First" philosophy, utilizing a restrained color palette and a clear visual hierarchy to reduce cognitive load during multi-tasking. The interface is intentionally quiet, allowing status-driven colors and critical alerts to command attention without competing with the UI chrome.

## Colors

This design system utilizes a structured color scale to differentiate between interactive elements, structural containers, and semantic statuses.

- **Primary Blue (#2563eb):** Reserved for primary actions, active navigation states, and key data focal points.
- **Surface Strategy:** Use `#f8fafc` for the global background and `#ffffff` for cards and content containers to create a subtle but clear "layered" effect.
- **Semantic Logic:** Status colors (Success, Pending, Critical) must be used sparingly. Use high-chroma versions for small indicators (chips, icons) and very low-saturation tints (5-10% opacity) for row highlights or container backgrounds to ensure text remains legible.
- **Neutral Scale:** Use `slate-900` for primary text and `secondary-gray` for metadata and borders.

## Typography

The typography system is built on **Inter**, chosen for its exceptional legibility in small sizes and its "tabular num" support. 

- **Numeric Data:** For all tracking IDs, coordinates, and timestamps, enable tabular lining figures (`tnum`) to ensure columns of numbers align vertically for quick scanning.
- **Scale:** The system uses a compact scale. `body-md` (14px) is the standard for most interface text, while `body-sm` (13px) is used for dense data tables and sidebars.
- **Hierarchy:** Use `label-md` in uppercase with slight tracking for section headers within panels to differentiate from interactive content.

## Layout & Spacing

This design system uses a **Fixed Grid** approach for the main dashboard content to maintain control over data density on large displays.

- **Grid Model:** A 12-column grid with 16px gutters. For the main operations dashboard, use a "Master-Detail" layout: a fixed-width left sidebar (240px), a flexible central data table/map, and an optional right-side "Inspector" panel (320px).
- **Density:** Adopt a 4px base unit. Component padding should generally be `8px` (2 units) or `12px` (3 units) to keep the UI compact.
- **Table Layout:** Tables should use "sticky" headers and "auto-layout" columns that prioritize ID and Status fields.

## Elevation & Depth

To maintain a clean and modern look, the system avoids heavy shadows. Depth is communicated primarily through **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0 (Background):** `#f8fafc` — The canvas.
- **Level 1 (Cards/Tables):** `#ffffff` with a 1px solid border of `#e2e8f0`. No shadow.
- **Level 2 (Popovers/Dropdowns):** `#ffffff` with a subtle 1px border and a soft, tight shadow (0px 4px 6px -1px rgba(0, 0, 0, 0.05)).
- **Interactive State:** Buttons and active inputs should use a subtle inner shadow or a distinct border-color change rather than a physical lift.

## Shapes

The shape language is **Soft (0.25rem)**, reflecting a professional and systematic environment. 

- **Standard Elements:** Buttons, input fields, and small cards use a 4px (0.25rem) radius.
- **Large Containers:** Main content areas or dashboard sections may use 8px (0.5rem) to provide a softer frame for dense internal data.
- **Status Indicators:** Status chips/badges should be pill-shaped (full rounding) to visually distinguish them from rectangular buttons and data fields.

## Components

- **Dense Tables:** Use a 40px row height. Cell text should be `body-sm`. Vertical borders are omitted; use 1px horizontal dividers in `slate-200`. Use subtle background hover states (`#f1f5f9`) to guide the eye.
- **Status Chips:** Small, uppercase labels with a background tint that matches the status color at 10% opacity. Text should use the full-saturation status color for contrast.
- **Action Cards:** Compact containers for "Last Mile" alerts. Title in `headline-sm`, metadata in `label-sm`. Actions should be tucked into the bottom right or available via a "more" icon.
- **Input Fields:** Use 1px borders. Focused states should use the `primary-blue` for the border and a subtle glow (2px spread, 15% opacity). Labels should be top-aligned and use `label-md`.
- **Primary Buttons:** Solid `primary-blue` background with white text. Height: 36px for standard, 32px for compact/table-actions.
- **Secondary Buttons:** Ghost style (transparent background) with `secondary-gray` border and text.